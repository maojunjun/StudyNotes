package de.greenrobot.daotest.customtype;

public class MyTimestamp {
    public long timestamp;
}
