package de.greenrobot.daotest;

public interface TestInterface {

}
